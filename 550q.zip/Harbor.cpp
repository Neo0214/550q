#include "Harbor.h"

Harbor::Harbor(int _Id,int _x, int _y, int _time, int _velocity)
{
	Id = _Id;
	x = _x;
	y = _y;
	time = _time;
	velocity = _velocity;
	isLocked = false;
}
Harbor::Harbor() {

}